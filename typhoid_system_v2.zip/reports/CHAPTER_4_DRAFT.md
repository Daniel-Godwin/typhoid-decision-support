# Chapter Four — Results and Discussion

_Draft generated from the project artefacts. Every figure below is read directly from `reports/`; regenerate with `python scripts/make_chapter4.py` after any retraining. Prose is a starting point to be rewritten in your own voice._

## 4.1 Introduction

This chapter presents the results of the Support Vector Machine models developed in Chapter Three. It reports the dataset characteristics established by the audit, the comparison of kernel functions, the outcome of hyperparameter optimisation, the performance of the optimised models on the held-out test partition, and the evaluation of scalability across geographic settings required by Objective 4. It closes with a signal audit of the dataset itself, which materially qualifies how the headline performance figures should be interpreted.

## 4.2 Dataset characteristics

The dataset comprises **31,087 patient records** across **23 attributes**, with **0 duplicate rows**. Four attributes contain missing values, the most affected being `Complications` at 96.98%.

**Table 4.1: Distribution of the four-class target**

| Class | Count | Percentage |
|---|---|---|
| Normal or No Typhoid | 21,701 | 69.81% |
| Acute Typhoid Fever | 5,649 | 18.17% |
| Relapsing Typhoid | 2,486 | 8.00% |
| Complicated Typhoid | 1,251 | 4.02% |

**Table 4.2: Distribution of the binary diagnostic target**

| Class | Count | Percentage |
|---|---|---|
| No Typhoid | 21,701 | 69.81% |
| Typhoid | 9,386 | 30.19% |

The four-class target is markedly imbalanced, with a ratio of 17.35 : 1 between the largest and smallest class. This motivated the SMOTENC balancing described in Section 3.2.1, applied inside the modelling pipeline so that synthetic samples were generated from training folds only and never contaminated validation or test data.

Following the feature policy set out in Section 3.2.1, `Blood Culture Result` and `Complications` were withheld from every model. The first is the confirmatory gold standard, so a model consuming it would be restating a completed diagnosis rather than predicting one; the second encodes post-diagnostic severity and is unavailable at the point of decision.

## 4.3 Kernel comparison

Three kernel functions — linear, polynomial and radial basis function — were evaluated at default hyperparameter settings on the held-out test partition, to establish which family of decision boundaries suited the data before committing to an exhaustive search.

**Table 4.3: Kernel comparison, binary diagnostic model**

| kernel | accuracy | balanced_accuracy | macro_f1 | weighted_f1 | fit_predict_seconds |
|---|---|---|---|---|---|
| linear | 0.9875 | 0.9792 | 0.9849 | 0.9874 | 35.0 |
| poly | 0.983 | 0.9718 | 0.9794 | 0.9828 | 42.4 |
| rbf | 0.9773 | 0.9624 | 0.9725 | 0.9771 | 68.2 |

**Table 4.4: Kernel comparison, four-class severity model**

| kernel | accuracy | balanced_accuracy | macro_f1 | weighted_f1 | fit_predict_seconds |
|---|---|---|---|---|---|
| linear | 0.8681 | 0.7363 | 0.7347 | 0.8701 | 492.0 |
| poly | 0.8731 | 0.7301 | 0.7341 | 0.8728 | 240.4 |
| rbf | 0.8705 | 0.7199 | 0.7266 | 0.8677 | 261.3 |

For the binary model the linear kernel produced the highest macro F1 (0.9849). The three kernels differed by less than one percentage point in accuracy, which indicates that the decision boundary separating the classes is close to linear in the encoded feature space — a point returned to in Section 4.7.

## 4.4 Hyperparameter optimisation

For the **binary diagnostic model**, Grid Search evaluated **24 candidate configurations** under **3-fold stratified cross-validation**, selecting on macro F1. The search used the full training partition of 24,869 records. The selected configuration was `{'svc__C': 10.0, 'svc__degree': 2, 'svc__gamma': 0.1, 'svc__kernel': 'poly'}`, achieving a cross-validated macro F1 of **0.9847** in 935 seconds of wall-clock time.

For the **four-class severity model**, Grid Search evaluated **24 candidate configurations** under **3-fold stratified cross-validation**, selecting on macro F1. Because oversampling expands the four-class training partition to roughly four times the majority class, the search was executed on a stratified subsample of 10,000 records and the winning configuration then refitted on the complete training partition. The selected configuration was `{'svc__C': 10.0, 'svc__degree': 2, 'svc__gamma': 'scale', 'svc__kernel': 'poly'}`, achieving a cross-validated macro F1 of **0.7435** in 824 seconds of wall-clock time.

The complete search results, including the score of every candidate configuration, are recorded in `reports/grid_search_results_binary.csv` and `reports/grid_search_results_multiclass.csv`.

## 4.5 Performance of the optimised models

**Table 4.5: Performance of the optimised models on the held-out test partition**

| model | kernel | C | gamma | accuracy | balanced_accuracy | macro_precision | macro_recall | macro_f1 | weighted_f1 | sensitivity | specificity | fpr | fnr | roc_auc | inference_ms_per_record |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Binary diagnosis | poly | 10.0 | 0.1 | 0.9881 | 0.9803 | 0.9916 | 0.9803 | 0.9857 | 0.988 | 0.9606 | 1.0 | 0.0 | 0.0394 | 0.9797 | 9.96 |
| Severity stratification | poly | 10.0 | scale | 0.8697 | 0.7394 | 0.7455 | 0.7394 | 0.7377 | 0.8717 | nan | nan | nan | nan | nan | 19.04 |

The optimised binary model achieved an accuracy of **98.81%**, balanced accuracy of **98.03%** and macro F1 of **0.9857** on 6,218 unseen records. Sensitivity was **0.9606** and specificity **1.0000**, corresponding to 74 false negatives and 0 false positives.

The clinical asymmetry of these two errors matters. A false negative is a missed typhoid case sent home untreated; a false positive is an unnecessary confirmatory test. The model's perfect specificity means it never raises a false alarm, but its sensitivity of 0.9606 means roughly 3.9% of true cases are missed — which is the error that carries clinical risk. Section 4.7 explains why these particular cases are missed.

Inference latency was **9.96 ms per record** (6,329.7 records per second in batch), which satisfies the real-time, point-of-care requirement of Objective 3.

**Table 4.6: Per-class precision, recall and F1**

| model | class | precision | recall | f1_score | support |
|---|---|---|---|---|---|
| Binary | No Typhoid | 0.9832 | 1.0 | 0.9915 | 4341 |
| Binary | Typhoid | 1.0 | 0.9606 | 0.9799 | 1877 |
| Four-class | Normal or No Typhoid | 0.9859 | 1.0 | 0.9929 | 4341 |
| Four-class | Acute Typhoid Fever | 0.6928 | 0.5389 | 0.6063 | 1130 |
| Four-class | Relapsing Typhoid | 0.3032 | 0.4185 | 0.3516 | 497 |
| Four-class | Complicated Typhoid | 1.0 | 1.0 | 1.0 | 250 |

The four-class model achieved accuracy of **86.97%** and macro F1 of **0.7377**. Performance was highly uneven across classes: *Normal or No Typhoid* and *Complicated Typhoid* were classified almost perfectly, while *Acute Typhoid Fever* and *Relapsing Typhoid* were frequently confused with one another. Section 4.7 shows that this pattern is a property of the dataset rather than a limitation of the classifier.

Confusion matrices for both models, together with ROC and precision–recall curves for the binary model, are provided in `reports/figures/`.

## 4.6 Scalability across geographic settings (Objective 4)

Objective 4 requires the model to be evaluated across diverse geographic regions and healthcare environments. The held-out test partition was therefore stratified by the `Location` attribute and the full metric set recomputed within each subgroup.

**Table 4.7: Performance by geographic setting**

| model | subgroup | n | accuracy | balanced_accuracy | macro_precision | macro_recall | macro_f1 | sensitivity | specificity |
|---|---|---|---|---|---|---|---|---|---|
| Binary | Endemic | 2084 | 0.9861 | 0.9781 | 0.99 | 0.9781 | 0.9838 | 0.9562 | 1.0 |
| Binary | Rural | 2046 | 0.9922 | 0.9864 | 0.9946 | 0.9864 | 0.9904 | 0.9728 | 1.0 |
| Binary | Urban | 2088 | 0.9861 | 0.9769 | 0.9903 | 0.9769 | 0.9832 | 0.9537 | 1.0 |
| Four-class | Endemic | 2063 | 0.8682 | 0.7391 | 0.7451 | 0.7391 | 0.7396 | nan | nan |
| Four-class | Rural | 2090 | 0.8651 | 0.7484 | 0.7509 | 0.7484 | 0.7414 | nan | nan |
| Four-class | Urban | 2065 | 0.876 | 0.7279 | 0.738 | 0.7279 | 0.7288 | nan | nan |

Macro F1 varied by only **0.0072** across the endemic, rural and urban subgroups. The model therefore does not degrade in any one setting, which satisfies Objective 4 as stated. This stability should, however, be read alongside Section 4.7: `Location` is statistically independent of the diagnosis in this dataset, so uniform performance across locations reflects the absence of geographic variation in the data rather than demonstrated robustness to it.

## 4.7 Signal audit and interpretation of the results

A model that reports high accuracy has not necessarily learned anything useful. To establish what the classifier had actually learned, three reference classifiers were scored on the identical test partition, and the statistical association between every attribute and the diagnosis was measured.

**Table 4.8: Reference baselines, binary diagnostic task**

| model | accuracy | balanced_accuracy | macro_precision | macro_recall | macro_f1 |
|---|---|---|---|---|---|
| Majority class ('No Typhoid') | 0.6981 | 0.5 | 0.3491 | 0.5 | 0.4111 |
| Rule: Fever Duration (Days) >= 1 | 0.9875 | 0.9792 | 0.9912 | 0.9792 | 0.9849 |
| Optimised SVM (routine policy) | 0.9881 | 0.9803 | 0.9916 | 0.9803 | 0.9857 |
| Optimised SVM (fever duration removed) | 0.6012 | 0.5485 | 0.545 | 0.5485 | 0.5454 |

Of the 8,981 records with a fever duration of one day or more, **8,981 — that is, every one of them — are labelled typhoid.** No record in the dataset combines a fever duration of one day or more with a negative diagnosis. `Fever Duration (Days)` is therefore a deterministic proxy for the target, and a single threshold on that one attribute reproduces almost the entire performance of the optimised model.

**Table 4.9: Reference baselines, four-class task**

| model | accuracy | balanced_accuracy | macro_precision | macro_recall | macro_f1 |
|---|---|---|---|---|---|
| Majority class | 0.6981 | 0.25 | 0.1745 | 0.25 | 0.2056 |
| Rules: WBC > 11,000 -> Complicated; fever >= 1 -> Acute | 0.9133 | 0.7396 | 0.6709 | 0.7396 | 0.7002 |
| Optimised SVM (four-class) | 0.8697 | 0.7394 | 0.7455 | 0.7394 | 0.7377 |

A second deterministic rule governs the four-class task: every record labelled *Complicated Typhoid* has a white blood cell count above 11,000, and no record of any other class does. The two ranges do not overlap by a single count, which is why the model classifies that class perfectly. A two-rule baseline outperforms the optimised four-class SVM on accuracy.

**Table 4.10: Association between each attribute and the diagnosis**

| feature | statistic | value |
|---|---|---|
| Blood Culture Result | Cramer's V | 0.9999 |
| Fever Duration (Days) | point-biserial r | 0.8138 |
| Complications | Cramer's V | 0.2685 |
| White Blood Cell Count | point-biserial r | 0.1948 |
| Water Source Type | Cramer's V | 0.0132 |
| Location | Cramer's V | 0.012 |
| Neurological Symptoms | Cramer's V | 0.0091 |
| Ongoing Infection in Society | Cramer's V | 0.0073 |
| Sanitation Facilities | Cramer's V | 0.0069 |
| Socioeconomic Status | Cramer's V | 0.0066 |
| Typhidot Test | Cramer's V | 0.0065 |
| Gastrointestinal Symptoms | Cramer's V | 0.0052 |
| Previous History of Typhoid | Cramer's V | 0.0045 |
| Hand Hygiene | Cramer's V | 0.0042 |
| Consumption of Street Food | Cramer's V | 0.0035 |
| Platelet Count | point-biserial r | -0.0026 |
| Weather Condition | Cramer's V | 0.0023 |
| Skin Manifestations | Cramer's V | 0.0022 |
| Typhoid Vaccination Status | Cramer's V | 0.0021 |
| Age | point-biserial r | 0.0014 |
| Widal Test | Cramer's V | 0.0014 |
| Gender | Cramer's V | 0.0008 |

Outside of `Blood Culture Result` (withheld), `Fever Duration (Days)` and `White Blood Cell Count`, no attribute reaches a Cramér's V of 0.02. `Widal Test` (V = 0.0014) and `Typhidot Test` (V = 0.0065) are statistically independent of the diagnosis — an impossibility in real patient data, since these are the serological tests on which typhoid diagnosis conventionally rests.

### Ablation

**Table 4.11: Feature policy sensitivity and ablation**

| feature policy | accuracy | balanced_accuracy | macro_f1 | sensitivity | specificity | roc_auc |
|---|---|---|---|---|---|---|
| Routine — all permitted attributes | 0.9881 | 0.9803 | 0.9857 | 0.9606 | 1.0 | 0.9797 |
| Pre-laboratory — Widal and Typhidot removed | 0.9875 | 0.9792 | 0.9849 | 0.9584 | 1.0 | 0.9802 |
| Ablation — Fever Duration (Days) removed | 0.6012 | 0.5485 | 0.5454 | 0.4156 | 0.6814 | 0.5729 |

With `Fever Duration (Days)` removed, performance collapses to an accuracy of **60.12%** and a balanced accuracy of **0.5485** — against a chance floor of 0.5000. The remaining nineteen attributes, taken together, therefore carry only marginal discriminative information about the diagnosis.

Taken together, these results establish that the dataset's apparent predictability is an artefact of its construction. The dataset is synthetic: the label is encoded deterministically into two attributes, one class distinction (*Acute* versus *Relapsing*) is not encoded at all, and the remaining attributes are effectively random with respect to the outcome. Realistic column names and plausible marginal distributions disguise this, but the joint distribution does not support the clinical relationships the attributes imply.

This does not invalidate the system developed in this study. The preprocessing pipeline, leakage controls, resampling strategy, optimisation procedure, evaluation protocol and deployed interface are all sound, and would transfer without modification to real clinical data. What the finding does establish is that the headline accuracy of 98.81% must not be presented as evidence that machine learning improves typhoid diagnosis — because a single threshold on one attribute achieves substantially the same result. Section 1.6 of this work anticipated precisely this risk in noting the study's dependency on existing datasets.

## 4.8 Summary of findings

1. A complete SVM diagnostic pipeline was implemented to the specification of Chapter Three, covering preprocessing, SMOTENC balancing, kernel experimentation, cross-validated optimisation, evaluation and deployment.
2. The optimised binary model achieved 98.81% accuracy and 0.9857 macro F1 on unseen data, with inference latency of 9.96 ms per record, satisfying the real-time requirement of Objective 3.
3. Performance was uniform across endemic, rural and urban subgroups, satisfying Objective 4 as stated.
4. A signal audit established that the dataset encodes the label deterministically into `Fever Duration (Days)` and `White Blood Cell Count`, that *Acute* and *Relapsing Typhoid* are not separable by any attribute, and that the remaining attributes are effectively independent of the outcome.
5. Consequently the reported accuracy measures the dataset's construction rather than the model's diagnostic capability, and validation on real clinical data is required before any claim of diagnostic utility can be made.
